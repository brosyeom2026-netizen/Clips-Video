# Clips Video (Android)

An English-language Android app that splits a selected video into sequential MP4 segments. The default segment length is 15 minutes; users can change it.

## Build the APK
1. Install Android Studio (recent stable version) with Android SDK Platform 35.
2. Open this `ClipsVideo` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location (normally `app/build/outputs/apk/debug/app-debug.apk`).

## Use
1. Tap **Choose video** and select a video.
2. Tap **Choose save folder** and select a folder (for example, Movies/Clips Video).
3. Leave clip length at 15 or enter another number of minutes.
4. Tap **Split video** and wait for the clips to be exported.

## Notes
- Requires Android 8.0 (API 26) or later.
- Uses Android MediaExtractor/MediaMuxer to copy supported audio/video streams without re-encoding. Some uncommon codecs or container layouts may not mux successfully.
- Segment boundaries are approximate at video keyframes; this is a stream-copy splitter, not a frame-accurate transcoder.
- The current version exports sequential files to the folder selected by the user. It does not upload or share videos automatically.
