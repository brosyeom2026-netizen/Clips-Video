package com.clipsvideo.app

import android.app.Activity
import android.content.Intent
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.*
import androidx.documentfile.provider.DocumentFile
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.min

class MainActivity : Activity() {
    private val pickVideo = 1001
    private val pickFolder = 1002
    private var videoUri: Uri? = null
    private var folderUri: Uri? = null
    private lateinit var videoLabel: TextView
    private lateinit var folderLabel: TextView
    private lateinit var durationInput: EditText
    private lateinit var status: TextView
    private lateinit var splitButton: Button
    private val executor = Executors.newSingleThreadExecutor()
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFFF6F7FB.toInt())
        }
        val title = TextView(this).apply {
            text = "Clips Video"
            textSize = 30f
            setTextColor(0xFF18223A.toInt())
            gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        val subtitle = TextView(this).apply {
            text = "Split long videos into smaller MP4 clips"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(0xFF596579.toInt())
        }
        layout.addView(title, params(LinearLayout.LayoutParams.MATCH_PARENT, 56))
        layout.addView(subtitle, params(LinearLayout.LayoutParams.MATCH_PARENT, 42))

        videoLabel = label("No video selected")
        folderLabel = label("No save folder selected")
        layout.addView(actionButton("1. Choose video") { openVideoPicker() })
        layout.addView(videoLabel, params(LinearLayout.LayoutParams.MATCH_PARENT, 56))
        layout.addView(actionButton("2. Choose save folder") { openFolderPicker() })
        layout.addView(folderLabel, params(LinearLayout.LayoutParams.MATCH_PARENT, 56))

        layout.addView(label("Clip length (minutes)"))
        durationInput = EditText(this).apply {
            setText("15")
            textSize = 20f
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(18, 8, 18, 8)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        layout.addView(durationInput, params(LinearLayout.LayoutParams.MATCH_PARENT, 58))
        splitButton = actionButton("Split video") { startSplit() }
        layout.addView(splitButton)
        status = label("Ready. Choose a video and a save folder to begin.")
        status.setTextColor(0xFF2456A6.toInt())
        layout.addView(status, params(LinearLayout.LayoutParams.MATCH_PARENT, 100))
        val foot = TextView(this).apply {
            text = "Clips are exported in order. Video and audio streams are copied without re-encoding when the source format is supported."
            textSize = 12f
            setTextColor(0xFF6B7280.toInt())
        }
        layout.addView(foot)
        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun params(w: Int, h: Int) = LinearLayout.LayoutParams(w, h).apply {
        bottomMargin = 14
    }
    private fun label(textValue: String) = TextView(this).apply {
        text = textValue
        textSize = 14f
        setTextColor(0xFF263247.toInt())
        gravity = Gravity.CENTER_VERTICAL
    }
    private fun actionButton(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue
        textSize = 16f
        setOnClickListener { action() }
        layoutParams = params(LinearLayout.LayoutParams.MATCH_PARENT, 58)
    }

    private fun openVideoPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, pickVideo)
    }

    private fun openFolderPicker() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, pickFolder)
    }

    @Deprecated("Use Activity Result APIs in a future update")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val flags = data.flags and (Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        try { contentResolver.takePersistableUriPermission(uri, flags) } catch (_: Exception) {}
        if (requestCode == pickVideo) {
            videoUri = uri
            videoLabel.text = "Selected: ${uri.lastPathSegment ?: "Video"}"
        } else if (requestCode == pickFolder) {
            folderUri = uri
            folderLabel.text = "Save to: ${DocumentFile.fromTreeUri(this, uri)?.name ?: "Selected folder"}"
        }
    }

    private fun startSplit() {
        val source = videoUri
        val target = folderUri
        val minutes = durationInput.text.toString().toLongOrNull()
        if (source == null || target == null) {
            status.text = "Please choose both a video and a save folder."
            return
        }
        if (minutes == null || minutes !in 1..600) {
            status.text = "Enter a clip length from 1 to 600 minutes."
            return
        }
        splitButton.isEnabled = false
        status.text = "Preparing video…"
        executor.execute {
            try {
                val count = splitVideo(source, target, minutes * 60L * 1_000_000L)
                handler.post { status.text = "Finished! Created $count clip(s)."; splitButton.isEnabled = true }
            } catch (e: Exception) {
                handler.post { status.text = "Could not split video: ${e.message ?: "Unsupported file"}"; splitButton.isEnabled = true }
            }
        }
    }

    private fun splitVideo(source: Uri, folder: Uri, segmentUs: Long): Int {
        val retriever = MediaMetadataRetriever()
        retriever.setDataSource(this, source)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong()
            ?: throw IllegalStateException("Cannot read video duration")
        retriever.release()
        val totalUs = durationMs * 1000L
        val directory = DocumentFile.fromTreeUri(this, folder) ?: throw IllegalStateException("Cannot open save folder")
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        var start = 0L
        var part = 1
        while (start < totalUs) {
            val end = min(start + segmentUs, totalUs)
            val out = directory.createFile("video/mp4", "ClipsVideo_${stamp}_%03d.mp4".format(Locale.US, part))
                ?: throw IllegalStateException("Cannot create output file")
            writeSegment(source, out.uri, start, end)
            handler.post { status.text = "Exported clip $part…" }
            start = end
            part++
        }
        return part - 1
    }

    private fun writeSegment(source: Uri, destination: Uri, startUs: Long, endUs: Long) {
        val inputPfd = contentResolver.openFileDescriptor(source, "r")
            ?: throw IllegalStateException("Cannot open source video")
        val outputPfd = contentResolver.openFileDescriptor(destination, "w")
            ?: throw IllegalStateException("Cannot create output video")
        val extractor = MediaExtractor()
        var muxer: MediaMuxer? = null
        try {
            extractor.setDataSource(inputPfd.fileDescriptor)
            muxer = MediaMuxer(outputPfd.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            val trackMap = HashMap<Int, Int>()
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    extractor.selectTrack(i)
                    trackMap[i] = muxer.addTrack(format)
                }
            }
            if (trackMap.isEmpty()) throw IllegalStateException("No supported audio/video tracks found")
            muxer.start()
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val firstSampleTime = extractor.sampleTime.coerceAtLeast(0L)
            val buffer = ByteBuffer.allocate(8 * 1024 * 1024)
            val info = MediaCodecBufferInfoCompat()
            while (true) {
                val track = extractor.sampleTrackIndex
                if (track < 0) break
                val time = extractor.sampleTime
                if (time >= endUs) break
                if (trackMap.containsKey(track)) {
                    buffer.clear()
                    val size = extractor.readSampleData(buffer, 0)
                    if (size < 0) break
                    info.set(0, size, (time - firstSampleTime).coerceAtLeast(0L), extractor.sampleFlags)
                    muxer.writeSampleData(trackMap[track]!!, buffer, info.toAndroidInfo())
                }
                if (!extractor.advance()) break
            }
            muxer.stop()
        } finally {
            try { muxer?.release() } catch (_: Exception) {}
            extractor.release()
            inputPfd.close()
            outputPfd.close()
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
