package com.clipsvideo.app

import android.media.MediaCodec

class MediaCodecBufferInfoCompat {
    private val info = MediaCodec.BufferInfo()
    fun set(offset: Int, size: Int, presentationTimeUs: Long, flags: Int) {
        info.set(offset, size, presentationTimeUs, flags)
    }
    fun toAndroidInfo(): MediaCodec.BufferInfo = info
}
